<template>
    <AdminLayout>
      <router-view></router-view>
    </AdminLayout>
  </template>
  
  <script>
  import AdminLayout from './layout.vue'
  export default {
    components:{
        AdminLayout,
    },
    mounted(){

    },
    methods:{

    }
}
  </script>
  
  
  <style scoped lang="less">
  </style>